package com.example.complaint.controller;

import com.example.complaint.model.Complaint;
import com.example.complaint.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ComplaintController {

    @Autowired
    private ComplaintService service;

    @GetMapping("/complaints")
    public List<Complaint> getAllComplaints() {
        return service.getAllComplaints();
    }

    @GetMapping("/complaint/{id}")
    public Complaint getComplaintById(@PathVariable Long id) {
        return service.getComplaintById(id);
    }

    @GetMapping("/complaints/status/open")
    public List<Complaint> getOpenComplaints() {
        return service.getOpenComplaints();
    }

    @PostMapping("/complaint")
    public Complaint createComplaint(@RequestBody Complaint complaint) {
        return service.createComplaint(complaint);
    }

    @PutMapping("/complaint/{id}")
    public Complaint updateComplaint(@PathVariable Long id, @RequestBody Complaint complaint) {
        return service.updateComplaint(id, complaint);
    }

    @DeleteMapping("/complaint/{id}")
    public String deleteComplaint(@PathVariable Long id) {
        service.deleteComplaint(id);
        return "Complaint with ID " + id + " deleted successfully.";
    }
}