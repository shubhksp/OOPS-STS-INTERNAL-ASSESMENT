package com.example.complaint.service;

import com.example.complaint.model.Complaint;
import com.example.complaint.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository repository;

    public List<Complaint> getAllComplaints() {
        return repository.findAll();
    }

    public Complaint getComplaintById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public List<Complaint> getOpenComplaints() {
        return repository.findByStatus("open");
    }

    public Complaint createComplaint(Complaint complaint) {
        return repository.save(complaint);
    }

    public Complaint updateComplaint(Long id, Complaint updatedComplaint) {
        Complaint complaint = repository.findById(id).orElse(null);
        if (complaint != null) {
            complaint.setDescription(updatedComplaint.getDescription());
            complaint.setStatus(updatedComplaint.getStatus());
            return repository.save(complaint);
        }
        return null;
    }

    public void deleteComplaint(Long id) {
        repository.deleteById(id);
    }
}